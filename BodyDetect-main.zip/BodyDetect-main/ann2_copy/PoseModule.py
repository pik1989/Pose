import cv2
import mediapipe as mp
import time


class poseDetector():

    #write parameter
    def __init__(self, mode = False, upBody = False, smooth = True,
                detectionCon = 0.5, trackCon = 0.5):

        self.mode = mode #self for object orientated
        self.upBody = upBody
        self.smooth = smooth
        self.detectionCon = detectionCon
        self.trackCon = trackCon

        self.mpDraw = mp.solutions.drawing_utils
        #detect the pose
        self.mpPose = mp.solutions.pose
        self.pose = self.mpPose.Pose(self.mode, self.upBody, self.smooth, self.detectionCon, self.trackCon) 
        #parameter on pose;
        #Solution APIs in https://google.github.io/mediapipe/solutions/pose#python-solution-api

    def findPose(self, img, draw = True):  #Ask the user to display on image or not
        #imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB) #mediapipe only apply in RGB, not effect in BGR, need to convert
        self.results = self.pose.process(img) #send the image to model
        #print(results.pose_landmarks) #show the landmark: {x,y,z,visibility} , in ratio of the image
        if self.results.pose_landmarks: #if result available
            if draw:
                self.mpDraw.draw_landmarks(img, self.results.pose_landmarks, self.mpPose.POSE_CONNECTIONS) 
                #results.pose_landmarks = Draw the point by the lib
                #mpPose.POSE_CONNECTIONS = Draw the line between points
        return img
        
    def findPosition(self, img, draw=True):
        lmList = [] #put it in list, (x,y,id, but also available for z and visability)
        if self.results.pose_landmarks: #if result available
            for id, lm in enumerate(self.results.pose_landmarks.landmark): #indicate which landmark, ref to documentation(graph)
                h,w,c = img.shape #height, weight, channel
                print(id, lm)
                cx, cy = int(lm.x*w), int(lm.y*h) #convert to actual pixel within integer
                lmList.append([id, cx, cy])
                if draw:
                #print circle on top on the point
                    cv2.circle(img, (cx,cy), 9, (255,0,0), cv2.FILLED) #blue doc with green line
        return lmList
        #Q1. How about turn the lmList into DataFrame and convert to csv?

##################################################################################################

def main(): #Testing code
    cap = cv2.VideoCapture('C:/Users/USER/Desktop/ann2/data/a.mp4')
    pTime = 0
    detector = poseDetector()
    while True:
        success, img = cap.read()
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img = detector.findPose(img)
        
        
        lmList = detector.findPosition(img)
        print(lmList[14]) #lmList[specific position that we want] in getting the numeric data
        cv2.circle(img, (lmList[14][1],lmList[14][2]), 15, (0,0,255), cv2.FILLED) #To visualise the specif. position
    #FPS cal
        cTime = time.time()
        fps = 1/(cTime-pTime)
        pTime = cTime

    #show the fps
        cv2.putText(img, str(int(fps)), (70,50), cv2.FONT_HERSHEY_PLAIN, 3,
                    (255, 0, 0), 3)

        cv2.imshow("Image", img)
        cv2.waitKey(1)

#If run itself, main function()
if __name__ == "__main__":
    main()