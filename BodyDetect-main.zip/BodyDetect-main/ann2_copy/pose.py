import cv2
import mediapipe as mp

#parameters of pose: (in default)
def __init__(self,
            static_image_mode = False, #If True, always find the new detection; False, confident is high on keep tracking
            upper_body_only=False, #If True: only detect and track on upper body
            smooth_landmarks = True, 
            min_detection_confidence = 0.5, #if con>0.5, detected and just keepon tracking; 
            min_tracking_confidence = 0.5): #if con>0.5, keep tracking, otherwise back to detection~