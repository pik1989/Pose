import cv2
import time
import PoseModule as pm


cap = cv2.VideoCapture('data/b.mp4')
pTime = 0
detector = pm.poseDetector()
while True:
    success, img = cap.read()
    img = detector.findPose(img)
    lmList = detector.findPosition(img)
    if len(lmList) != 0: #To avoid out of range
        print(lmList[14]) #lmList[specific position that we want] in getting the numeric data
        cv2.circle(img, (lmList[14][1],lmList[14][2]), 15, (0,0,255), cv2.FILLED) #To visualise the specif. position
    #FPS cal
    cTime = time.time()
    fps = 1/(cTime-pTime)
    pTime = cTime

    #show the fps
    cv2.putText(img, str(int(fps)), (70,50), cv2.FONT_HERSHEY_PLAIN, 3,
                (255, 0, 0), 3)

    cv2.imshow("Image", img)
    cv2.waitKey(1)