import cv2
import mediapipe as mp
import time

mpDraw = mp.solutions.drawing_utils
#detect the pose
mpPose = mp.solutions.pose
pose = mpPose.Pose() #parameter on pose;
    #Solution APIs in https://google.github.io/mediapipe/solutions/pose#python-solution-api

#read video
cap = cv2.VideoCapture('data/a.mp4')
pTime = 0

while True:
    success, img = cap.read()
    imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB) #mediapipe only apply in RGB, not effect in BGR, need to convert
    results = pose.process(imgRGB) #send the image to model
    #print(results.pose_landmarks) #show the landmark: {x,y,z,visibility} , in ratio of the image
    if results.pose_landmarks:
        mpDraw.draw_landmarks(img, results.pose_landmarks, mpPose.POSE_CONNECTIONS) 
        #results.pose_landmarks = Draw the point by the lib
        #mpPose.POSE_CONNECTIONS = Draw the line between points
        for id, lm in enumerate(results.pose_landmarks.landmark): #indicate which landmark, ref to documentation(graph)
            h,w,c = img.shape #height, weight, channel
            print(id, lm)
            cx, cy = int(lm.x*w), int(lm.y*h) #convert to actual pixel within integer
            
            #print circle on top on the point
            cv2.circle(img, (cx,cy), 9, (255,0,0), cv2.FILLED) #blue doc with green line



    #FPS cal
    cTime = time.time()
    fps = 1/(cTime-pTime)
    pTime = cTime

    #show the fps
    cv2.putText(img, str(int(fps)), (70,50), cv2.FONT_HERSHEY_PLAIN, 3,
                    (255, 0, 0), 3)
    cv2.imshow("yatfai45", img)

    cv2.waitKey(1)
