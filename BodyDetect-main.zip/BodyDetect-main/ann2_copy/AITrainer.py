import cv2
import numpy as np
import time
import PoseModule as pm
#PoseModule = Made by Julian before


cap = cv2.VideoCapture("AiTrainer/curls.mp4")

detector = pm.poseDetector()
count = 0 #
dir = 0 # direction 0 and direction 1, (0 = up, 1 = down; from 0 to 100 and 100 to 0; for full set of single movement: referring to (angle, per line 27))
pTime = 0 # add FPS

while True:
    success, img = cap.read()
    img = cv2.resize(img, (1280, 720)) #Resize video
    # img = cv2.imread("AiTrainer/test.png") #Use test image a first for angle, use the video for the curve (testing only)
    img = detector.findPose(img, False) #Draw to detect the pose
    lmList = detector.findPosition(img, False) #position landmark, False = not to drop
    
    #List position detected
    if len(lmList) != 0:
        # angle = detector.findAngle(img, 12, 14, 16) #Right arm (image)
        angle = detector.findAngle(img, 11, 13, 15) #Left arm (video)
                                                            #Check the graph, #11 ,13, 15 = left arm; #12, 14, 16 = right arm, just referring to the img

        per = np.inter(angle,(210,310),(0, 100)) #Angle or curve, (the actual angle in exercise seen),(convert angle -> not in video or image but in terminal)
        print(angle, per) #actual angle, percentange in angle 對應

        bar = np.interp(angle, (220, 310), (650, 100))#Control volume of computer ,min value to max value: 650, 100

        #check dumbbell curls
        color = (255,0,255) #change color: purple
        if per == 100:
            color = (255, 0 ,0) #color: red
            if dir == 0:
                count  += 0.5 #(the movement of up or down, only a half of single)
                dir = 1 #1=up, see dir = 0
        if per == 0:
            color = (0, 255 ,0) #color: green #color can be changed
            if dir == 1:
                count += 0.5 #(another movement, another half)
                dir = 0 #0=down, see dir = 0
        print(count)

        # Draw the Bar with creating rectangle box
        cv2.rectangle(img, (1100, 100), (1175, 650), color, 3) #Layer of bar
        #Bar movement - referring to "if par==100: if dir=0".
        cv2.rectangle(img, (1100, int(bar)), (1175, 650), color, cv2.FILLED) #The bar
        cv2.putText(img, f'{int(per)}%', (1100, 75), cv2.FONT_HENRSHEY_PLAIN, 4, #display in percentage
        color, 4) #The percentage

        #Create the number of box, whih put the number of counting exercise into it.!
        cv2.rectangle(img, (0, 450), (250, 720),(0, 255, 0), cv2.FILLED)
        #(0, 450),(250,720) == HD image
        #(0, 255, 0) == Box color == green

        #show the times of exercise in the video
        cv2.putText(img, str(count), (45, 670), cv2.FONT_HENRSHEY_PLAIN, 15, #str(int(count)) is also available, (45, 670) = green area lo
        (255, 0, 0), 15) #display, can be {count}
            #FONT_HENRSHEY_PLAIN == font type, referring to the cv2 documentation.

    cTime = time.time()
    fps = 1/(cTime - pTime)
    pTime = cTime
    cv2.putText(img, str(int(fps)), (50, 100), cv2.FONT_HENRSHEY_PLAIN, 4, #str(int(count)) is also available
                (255, 0, 0), 5) #Also show the fps, if not showing the times of exercise

    cv2.imshow("Image", img)
    cv2.waitKey(1) #lower the fps
